// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Rasterize NDVI by field"); }
int main(){
  announce();
  return lionss_run_workload("petalmap");
}
