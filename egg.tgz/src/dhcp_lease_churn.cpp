// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Churn 5k clients over 1 h"); }
int main(){
  announce();
  return lionss_run_workload("dhcp_lease_churn");
}
