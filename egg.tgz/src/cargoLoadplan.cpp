// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Weight-and-balance load plan"); }
int main(){
  announce();
  return lionss_run_workload("cargoLoadplan");
}
