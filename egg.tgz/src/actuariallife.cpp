// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(int argc, char** argv){
  (void)argc; (void)argv;
  std::printf("%s\n", "Price 20-year term");
  std::fflush(stdout);
  return lionss_run_workload("actuariallife");
}
