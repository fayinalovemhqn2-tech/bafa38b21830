// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Demosaic, WB 5200K, export"); }
int main(){
  announce();
  return lionss_run_workload("raw-develop");
}
