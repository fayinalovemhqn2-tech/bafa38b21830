// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Fetch and cache staple"); }
int main(){
  announce();
  return lionss_run_workload("ocsp-stapler");
}
