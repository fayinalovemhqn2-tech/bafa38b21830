// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("Plan 7 days under 2100 kcal\n", stdout);
  return lionss_run_workload("mealPlanner");
}
