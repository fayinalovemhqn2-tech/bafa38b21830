// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("Batch inference, 128 images\n", stdout);
  return lionss_run_workload("larch");
}
