// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("Detect flaky tests over 100 runs\n", stdout);
  return lionss_run_workload("dory");
}
