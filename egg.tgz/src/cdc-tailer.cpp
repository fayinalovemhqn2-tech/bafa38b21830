// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("Decode changes and emit events\n", stdout);
  return lionss_run_workload("cdc-tailer");
}
