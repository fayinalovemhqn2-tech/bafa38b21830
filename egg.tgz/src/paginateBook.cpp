// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Paginate with widow control"); }
int main(){
  announce();
  return lionss_run_workload("paginateBook");
}
