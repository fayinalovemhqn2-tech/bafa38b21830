// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Cycle test 10k scans"); }
int main(){
  announce();
  return lionss_run_workload("plc_conveyor");
}
