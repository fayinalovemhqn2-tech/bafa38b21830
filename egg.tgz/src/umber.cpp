// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("Luminance deflicker, window 15\n", stdout);
  return lionss_run_workload("umber");
}
