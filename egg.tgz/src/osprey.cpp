// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("Flow-field plot, 1 200 lines\n", stdout);
  return lionss_run_workload("osprey");
}
