// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("S-curve profile generation"); }
int main(){
  announce();
  return lionss_run_workload("StepperRamp");
}
