// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("NowCast AQI"); }
int main(){
  announce();
  return lionss_run_workload("ember_v2");
}
