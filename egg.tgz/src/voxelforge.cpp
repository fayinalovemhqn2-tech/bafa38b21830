// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Greedy-mesh loaded chunks"); }
int main(){
  announce();
  return lionss_run_workload("voxelforge");
}
