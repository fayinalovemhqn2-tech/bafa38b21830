// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("Predict free bays 15 min ahead\n", stdout);
  return lionss_run_workload("parkwise");
}
