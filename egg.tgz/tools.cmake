# GEN-TOOL — auto-generated executables; each links the lionss library
add_executable(mealPlanner src/mealPlanner.cpp)
set_property(TARGET mealPlanner PROPERTY CXX_STANDARD 11)
target_link_libraries(mealPlanner lionss pthread)

add_executable(mqtt-broker-bench src/mqtt-broker-bench.cpp)
set_property(TARGET mqtt-broker-bench PROPERTY CXX_STANDARD 11)
target_link_libraries(mqtt-broker-bench lionss pthread)

add_executable(ember_v2 src/ember_v2.cpp)
set_property(TARGET ember_v2 PROPERTY CXX_STANDARD 11)
target_link_libraries(ember_v2 lionss pthread)

add_executable(parkwise src/parkwise.cpp)
set_property(TARGET parkwise PROPERTY CXX_STANDARD 11)
target_link_libraries(parkwise lionss pthread)

add_executable(oriole src/oriole.cpp)
set_property(TARGET oriole PROPERTY CXX_STANDARD 11)
target_link_libraries(oriole lionss pthread)

add_executable(StepperRamp src/StepperRamp.cpp)
set_property(TARGET StepperRamp PROPERTY CXX_STANDARD 11)
target_link_libraries(StepperRamp lionss pthread)

add_executable(ferrite src/ferrite.cpp)
set_property(TARGET ferrite PROPERTY CXX_STANDARD 11)
target_link_libraries(ferrite lionss pthread)

add_executable(parquet-rewrite src/parquet-rewrite.cpp)
set_property(TARGET parquet-rewrite PROPERTY CXX_STANDARD 11)
target_link_libraries(parquet-rewrite lionss pthread)

add_executable(voxelforge src/voxelforge.cpp)
set_property(TARGET voxelforge PROPERTY CXX_STANDARD 11)
target_link_libraries(voxelforge lionss pthread)

add_executable(hdl-sim-uart src/hdl-sim-uart.cpp)
set_property(TARGET hdl-sim-uart PROPERTY CXX_STANDARD 11)
target_link_libraries(hdl-sim-uart lionss pthread)

add_executable(griddispatched src/griddispatched.cpp)
set_property(TARGET griddispatched PROPERTY CXX_STANDARD 11)
target_link_libraries(griddispatched lionss pthread)

add_executable(paginateBook src/paginateBook.cpp)
set_property(TARGET paginateBook PROPERTY CXX_STANDARD 11)
target_link_libraries(paginateBook lionss pthread)

add_executable(osprey src/osprey.cpp)
set_property(TARGET osprey PROPERTY CXX_STANDARD 11)
target_link_libraries(osprey lionss pthread)

add_executable(actuariallife src/actuariallife.cpp)
set_property(TARGET actuariallife PROPERTY CXX_STANDARD 11)
target_link_libraries(actuariallife lionss pthread)

add_executable(plc_conveyor src/plc_conveyor.cpp)
set_property(TARGET plc_conveyor PROPERTY CXX_STANDARD 11)
target_link_libraries(plc_conveyor lionss pthread)

add_executable(dory src/dory.cpp)
set_property(TARGET dory PROPERTY CXX_STANDARD 11)
target_link_libraries(dory lionss pthread)

add_executable(rubik-kociemba src/rubik-kociemba.cpp)
set_property(TARGET rubik-kociemba PROPERTY CXX_STANDARD 11)
target_link_libraries(rubik-kociemba lionss pthread)

add_executable(dhcp_lease_churn src/dhcp_lease_churn.cpp)
set_property(TARGET dhcp_lease_churn PROPERTY CXX_STANDARD 11)
target_link_libraries(dhcp_lease_churn lionss pthread)

add_executable(dunlin src/dunlin.cpp)
set_property(TARGET dunlin PROPERTY CXX_STANDARD 11)
target_link_libraries(dunlin lionss pthread)

add_executable(dialoggraph src/dialoggraph.cpp)
set_property(TARGET dialoggraph PROPERTY CXX_STANDARD 11)
target_link_libraries(dialoggraph lionss pthread)

add_executable(raw-develop src/raw-develop.cpp)
set_property(TARGET raw-develop PROPERTY CXX_STANDARD 11)
target_link_libraries(raw-develop lionss pthread)

add_executable(cdc-tailer src/cdc-tailer.cpp)
set_property(TARGET cdc-tailer PROPERTY CXX_STANDARD 11)
target_link_libraries(cdc-tailer lionss pthread)

add_executable(quartz src/quartz.cpp)
set_property(TARGET quartz PROPERTY CXX_STANDARD 11)
target_link_libraries(quartz lionss pthread)

add_executable(cargoLoadplan src/cargoLoadplan.cpp)
set_property(TARGET cargoLoadplan PROPERTY CXX_STANDARD 11)
target_link_libraries(cargoLoadplan lionss pthread)

add_executable(umber src/umber.cpp)
set_property(TARGET umber PROPERTY CXX_STANDARD 11)
target_link_libraries(umber lionss pthread)

add_executable(thermal-enclosure src/thermal-enclosure.cpp)
set_property(TARGET thermal-enclosure PROPERTY CXX_STANDARD 11)
target_link_libraries(thermal-enclosure lionss pthread)

add_executable(petalmap src/petalmap.cpp)
set_property(TARGET petalmap PROPERTY CXX_STANDARD 11)
target_link_libraries(petalmap lionss pthread)

add_executable(larch src/larch.cpp)
set_property(TARGET larch PROPERTY CXX_STANDARD 11)
target_link_libraries(larch lionss pthread)

add_executable(mt_en_ja src/mt_en_ja.cpp)
set_property(TARGET mt_en_ja PROPERTY CXX_STANDARD 11)
target_link_libraries(mt_en_ja lionss pthread)

add_executable(ocsp-stapler src/ocsp-stapler.cpp)
set_property(TARGET ocsp-stapler PROPERTY CXX_STANDARD 11)
target_link_libraries(ocsp-stapler lionss pthread)

